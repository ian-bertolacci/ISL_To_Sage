#include "util.hpp"
/*
void assertWithException( bool condition, const std::string& message ){
  if( !condition ){
    throw assert_exception( message );
  }
}*/
